## Restrictions example ontology

This restrictions example ontology illustrates several ontology constructs to show how to represent them in the OAS.

Note that this example was tested on macOS (hence the file path) and the working directory is assumed to be the above the "examples" folder
