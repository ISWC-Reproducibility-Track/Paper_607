## Model catalog: reduced example

This example illustrates how to load ontologies from local files. 

Note that this example was tested on Windows (hence the file path) and the working directory is assumed to be the above the "examples" folder